
  
  
<script  src="custom/js/jquery-1.11.1.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js" ></script>


<!-- Scrolling Nav JavaScript -->
    <script src="custom/js/jquery.easing.min.js"></script>
    <script src="custom/js/scrolling-nav.js"></script>


</body>
</html>

<?php
  // 5. Close database connection
	if (isset($connection)) {
	  mysqli_close($connection);
	}
?>


