<div ><br><br><br><br><br><br><br><br></div> 
<section id="developer" class="bg-light-gray well">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Our Amazing Team</h2>
                    <h3 class="section-subheading text-muted">Lorem ipsum dolor sit amet consectetur.</h3>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-4">
                    <div class="team-member">
                        <img src="img/team/1.jpg" class="img-responsive img-circle" alt="">
                        <h4 class="text-centre">Arun Pal</h4>
                        <p class="text-muted">Lead Designer</p>
   <a href="#"><i class="fa fa-twitter fa-2x" ></i></a>
   <a href="#" ><i class="fa fa-google-plus fa-2x "></i></a>
   <a href="#"><i class="fa fa-facebook fa-2x" ></i></a>
    

                        </div>
                </div>
                <div class="col-sm-4">
                    <div class="team-member">
                        <img src="img/team/2.jpg" class="img-responsive img-circle" alt="">
                        <ul class="list-inline"><h4>Jignesh Patel</h4>
                        <p class="text-muted">Lead Marketer</p>
                        <a href="#"><i class="fa fa-twitter fa-2x" ></i></a>
   <a href="#" ><i class="fa fa-google-plus fa-2x "></i></a>
   <a href="#"><i class="fa fa-facebook fa-2x" ></i></a>


                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="team-member">
                        <img src="img/team/3.jpg" class="img-responsive img-circle" alt="">
                        <h4>Shubham Shawant</h4>
                        <p class="text-muted">Lead Developer</p>
                        <a href="#"><i class="fa fa-twitter fa-2x" ></i></a>
   <a href="#" ><i class="fa fa-google-plus fa-2x "></i></a>
   <a href="#"><i class="fa fa-facebook fa-2x" ></i></a>
   

                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2 text-center">
                    <p class="large text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aut eaque, laboriosam veritatis, quos non quis ad perspiciatis, totam corporis ea, alias ut unde.</p>
                </div>
            </div>
        </div>
    </section> 

<footer class="navbar navbar-default navbar-fixed-bottom " >
  <div class="container">
   <p class="navbar-text pull-left" style="height:inherit">ADBMS Project,Copyright <?php echo date("Y"); ?></p>
   <div class="navbar-text pull-right">
   <a href="#"><i class="fa fa-twitter fa-2x" ></i></a>
   <a href="#" ><i class="fa fa-google-plus fa-2x "></i></a>
   <a href="#"><i class="fa fa-facebook fa-2x" ></i></a>
    <a href="#"><i class="icon-thumbs-up icon-3x main-color"></i></a>
   </div>
   
  
   </div>
  </footer>
  
  
<script  src="custom/js/jquery-1.11.1.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js" ></script>
 <script src="custom/js/cbpAnimatedHeader.js"></script>

<!-- Scrolling Nav JavaScript -->
    <script src="custom/js/jquery.easing.min.js"></script>
    <script src="custom/js/scrolling-nav.js"></script>


</body>
</html>

<?php
  // 5. Close database connection
	if (isset($connection)) {
	  mysqli_close($connection);
	}
?>


