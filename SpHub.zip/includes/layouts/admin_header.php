<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>SpHub' Admin</title>
<link rel="shortcut icon" href="../img/award.png" />

<link  href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="custom/css/style.css" rel="stylesheet" type="text/css" />
<link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
</head>

<body id="page-top" class="index" style="margin-top:200px;">

<div class="container">
    <div class="row">
        <div class="col-md-3">
            <ul class="nav nav-pills nav-stacked">
                <li class="active"><a href="#"><i class="fa fa-home fa-fw"></i>Home</a></li>
                <li><a href="#"><i class="fa fa-list-alt fa-fw"></i>Widgets</a></li>
                <li><a href="#"><i class="fa fa-file-o fa-fw"></i>Pages</a></li>
                <li><a href="#"><i class="fa fa-bar-chart-o fa-fw"></i>Charts</a></li>
                <li><a href="#"><i class="fa fa-table fa-fw"></i>Table</a></li>
                <li><a href="#"><i class="fa fa-tasks fa-fw"></i>Forms</a></li>
                <li><a href="#"><i class="fa fa-calendar fa-fw"></i>Calender</a></li>
                <li><a href="#"><i class="fa fa-book fa-fw"></i>Feedback</a></li>
                <li><a href="#"><i class="fa fa-pencil fa-fw"></i>Applications</a></li>
                <li><a href="#"><i class="fa fa-cogs fa-fw"></i>Settings</a></li>
            </ul>
        </div>
       